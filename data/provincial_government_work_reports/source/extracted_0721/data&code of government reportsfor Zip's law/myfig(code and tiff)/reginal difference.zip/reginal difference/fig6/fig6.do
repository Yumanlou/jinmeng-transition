clear all

use "E:\betabigcity.dta"

rename beta mybeta


bysort year bigarea: egen beta=mean(mybeta)





twoway (connected beta year if bigarea == "east", sort mcolor(blue)) ///
       (connected beta year if bigarea == "middle", sort mcolor(red)) ///
       (connected beta year if bigarea == "west", sort mcolor(green)) ///
       (connected beta year if bigarea == "northeast", sort mcolor(yellow)), ///
   xlabel(2003(2)2023)  legend(label(1 "east") label(2 "central") label(3 "west") label(4 "northeast") ) ytitle("{&beta}")

graph export "e:\fig6.tif", replace 