clear all

use "E:\betabigcity.dta"

rename beta mybeta


bysort year city: egen beta=mean(mybeta)





twoway (connected beta year if city == 1, sort mcolor(blue)) ///
       (connected beta year if city== 0, sort mcolor(red)), ///
   xlabel(2003(2)2023) xline(2015,lpattern(dash) lcolor(green) lwidth(thick)) ///
legend(label(1 "municipalities") label(2 "non-municipalities")) ytitle("{&beta}")
 graph export "e:\fig7.tif", replace 