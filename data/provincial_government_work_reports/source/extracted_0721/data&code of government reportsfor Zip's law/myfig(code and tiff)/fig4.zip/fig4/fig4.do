clear all

use "E:\zipfbeta.dta"

rename beta mybeta

bysort year : egen beta=mean(mybeta)

twoway (connected beta year ,sort),xlabel(2003(2)2023) xline(2011, lpattern(dash) lcolor(red) lwidth(thick)) ytitle("{&beta}") xtitle("year")


graph export "e:\fig4.tif", replace 