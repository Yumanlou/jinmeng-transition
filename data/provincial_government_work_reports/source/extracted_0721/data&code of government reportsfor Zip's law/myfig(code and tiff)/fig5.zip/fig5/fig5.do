clear all

use "E:\zipfbeta.dta"




* 生成五分位数组
bysort year: egen quintile = xtile(beta), nq(5)

* 计算各分位数均值
collapse (mean) x_mean = beta, by(year quintile)

* 转换为宽格式
reshape wide x_mean, i(year) j(quintile)

* 绘制趋势图
twoway (connected x_mean1 year) ///
       (connected x_mean2 year) ///
       (connected x_mean3 year) ///
       (connected x_mean4 year) ///
       (connected x_mean5 year), ///
      xlabel(2003(2)2023)   legend(label(1 "The lowest quintile") label(2 "The second quintile") label(3 "The median quintile") ///
      label(4 "The fourth quintile") label(5 "The highest quintile")) ytitle("{&beta}") xtitle("year")
      graph export "e:\fig5.tif", replace 