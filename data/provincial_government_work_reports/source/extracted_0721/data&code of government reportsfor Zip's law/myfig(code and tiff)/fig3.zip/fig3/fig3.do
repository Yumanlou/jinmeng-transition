clear all
use e:\zipfbeta
twoway (hist beta,lcolor(ltblue) ) ///
       (kdensity beta,lcolor(red) lwidth(thin) xtitle("{&beta}") ytitle("Density"))
graph export "e:\fig3.tif", replace 