clear all
use e:\zipfbeta

sort area year

graph twoway (scatter beta year), by(area, rows(9) note(""))  xtitle("year") ytitle("{&beta}")


graph export "e:\fig2.tif", replace 